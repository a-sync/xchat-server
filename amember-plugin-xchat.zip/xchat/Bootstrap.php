<?php

class Bootstrap_Xchat extends Am_Module
{
    const ADMIN_PERM_ID = 'xchatadmin';
    const CUSTOMER_PERM_ID = 'xchatcustomer';
    const MODEL_PERM_ID = 'xchatmodel';

    public function init()
    {
        parent::init();
    }

    public function onGetPermissionsList(Am_Event $event)
    {
        $event->addReturn("Can manage xchat time balance", self::ADMIN_PERM_ID);
        $event->addReturn("Can view models list and join model chat", self::CUSTOMER_PERM_ID);
        $event->addReturn("Can host model chat", self::MODEL_PERM_ID);
    }

    public function onUserMenu(Am_Event $event)
    {
        $user = $event->getUser();
        if ($user->data()->get('user_type') === Bootstrap_Subusers::USER_TYPE_CUSTOMER) {
            $page = array(
                'id' => 'xchat',
                'label' => ___('Models'),
                'module' => 'xchat',
                'controller' => 'index',
                'action' => 'list',
                'order' => 102,
                //'uri' => REL_ROOT_URL . '/xchat/list',
            );
        }
        else if ($user->data()->get('user_type') === Bootstrap_Subusers::USER_TYPE_MODEL
                 || $user->data()->get('user_type') === Bootstrap_Subusers::USER_TYPE_SUBMODEL) {
            $page = array(
                'id' => 'xchat',
                'label' => ___('My chat'),
                'module' => 'xchat',
                'controller' => 'index',
                'action' => 'chat',
                //'params' => array(), ? model login as room
                'order' => 102,
                //'uri' => REL_ROOT_URL . '/xchat/chat',
            );
        }

        $event->getMenu()->addPage($page);
    }

    public function onUserTabs(Am_Event $event)
    {
        $user_id = $event->getUserId();
        if ($user_id > 0)
        {
            $user = $this->getDi()->userTable->load($user_id, false);
            if (!$user) return;

            if($user) {
                $event->getTabs()->addPage(array(
                    'id' => 'xchat',
                    'module' => 'xchat',
                    'controller' => 'admin',
                    'action' => 'index',
                    'params' => array(
                        'user_id' => $event->getUserId(),
                    ),
                    'label' => ___('Xchat balance'),
                    'order' => 2002
                ));
            }
        }
    }

    public function onAdminMenu(Am_Event $event)
    {
        $menu = $event->getMenu();
        $menu->addPage(array(
            'id' => 'xchat',
            'uri' => 'javascript:;',
            'label' => ___('Xchat'),
            'resource' => self::ADMIN_PERM_ID,
            'pages' => array(
                array(
                    'id' => 'xchat-balances',
                    'controller' => 'admin-balances',
                    'module' => 'xchat',
                    'label' => ___("Xchat balances"),
                    'resource' => self::ADMIN_PERM_ID,
                )
            )
        ));
    }

}
