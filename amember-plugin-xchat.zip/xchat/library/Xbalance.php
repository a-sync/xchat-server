<?php

class Xbalance extends Am_Record {
    protected $_customer;
    protected $_model;

    public function getCustomer()
    {
        if (!$this->_customer)
            $this->_customer = $this->getDi()->userTable->load($this->customer_id);
        return $this->_customer;
    }

    public function getModel()
    {
        if (!$this->_model)
            $this->_model = $this->getDi()->userTable->load($this->model_id);
        return $this->_model;
    }
}

class XbalanceTable extends Am_Table {
    protected $_key = 'balance_id';
    protected $_table = '?_xchat_balance';
    protected $_recordClass = 'Xbalance';

    /*public function addTransaction($invoice, $payment, $recipient) {
        $transaction = $this->createRecord();

        $transaction->added = $this->getDi()->sqlDateTime;
        $transaction->user_id = $invoice->getUserId();
        $transaction->sender = $invoice->getLogin();
        $transaction->target_id = $recipient->user_id;
        $transaction->recipient = $recipient->login;
        $transaction->amount = $payment->amount;
        $transaction->comment = $invoice->data()->get('invcomment')?:"";
        $transaction->status = $invoice->getStatus();
        $transaction->currency = $payment->currency;
        $transaction->public_id = $invoice->public_id;
        $transaction->invoice_id = $invoice->invoice_id;
        $transaction->invoice_payment_id = $payment->invoice_payment_id;

        $transaction->insert();

        return $transaction;
    }*/

/*
    public function getTransactionByPublicData($public_id, $recipient_id, $sender_id) {
        $trecord = $this->findFirstBy(
            array(
                'public_id' => $public_id,
                'target_id' => $recipient_id,
                'user_id' => $sender_id
            )
            , 'transaction_id DESC');

        return $trecord;
    }

    public function getTransactionByInvoiceId($invoice_id) {
        $trecord = $this->findFirstBy(
            array(
                'invoice_id' => $invoice_id
            )
        , 'transaction_id DESC');

        return $trecord;
    }
*/
}

